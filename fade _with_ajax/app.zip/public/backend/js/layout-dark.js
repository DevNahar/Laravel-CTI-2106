(function($) {
    "use strict"

    new dezSettings({
        version: "dark"
    });


})(jQuery);