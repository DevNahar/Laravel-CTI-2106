
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>        
        <li class="breadcrumb-item active"><a href="">Inventory</a></li>
    </ol>
</div>
<div class="row">
    
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header"><h3>Inventory List</h3></div>
                <div class="card-body">
                    <table class="table table-striped">
                        <tr>
                            <th>SI</th>
                            <th>Product Name</th>
                            <th>Color</th>
                            <th>Size</th>
                            <th>Quantity</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $inventoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($product_info->product_name); ?></td>
                            <td><?php echo e($inventory->rel_to_color->color_name); ?></td>
                            <td><?php echo e($inventory->rel_to_size->color_size); ?></td>
                            <td><?php echo e($inventory->quantity); ?></td>
                            
                            <td><a href="" class="btn btn-danger btn-xs sharp"><i class="fa fa-trash"></i></a></td>
                            </tr>   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </table>
                </div>
            </div>
        </div>
   
    <div class="col-lg-4">
        <div class="card border border-primary">
            <div class="card-header bg-primary"><h3 class="text-white">Add Inventory</h3></div>
            <div class="card-body">
                <form action="<?php echo e(route('store.inventory', $product_info->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>                        
                            <input type="text" class="form-control " readonly value="<?php echo e($product_info->product_name); ?>" name="product_name">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Color</label>                        
                            <select name="color_id" class="form-control"> 
                                <option value="">--Select Color--</option>                               
                                <?php $__currentLoopData = $colorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($color->id); ?>"><?php echo e($color->color_name); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Size</label>                        
                            <select name="size_id" class="form-control"> 
                                <option value="">--Select Size--</option>                                
                                <?php $__currentLoopData = $sizeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($size->id); ?>"><?php echo e($size->color_size); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Quantity</label> 
                            <input type="text" name="quantity" class="form-control">  
                        </div>
                        <div class="mb-3">
                            <a href="<?php echo e(route('product.list')); ?>" class="btn btn-primary">Product list</a>
                            <button type="submit" class="btn btn-primary">Add Inventory</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel-CTI-2106\fade\resources\views/admin/product/inventory.blade.php ENDPATH**/ ?>