<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('category')); ?>">Category</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('subcategory')); ?>">Subcategory</a></li>
    </ol>
</div>
<div class="row">
    <div class="col-lg-4 m-auto">
        <div class="card border border-primary">
            <div class="card-header bg-primary"><h3 class="text-white">Update Subcategory</h3></div>

            <div class="card-body">
                
                <form action="<?php echo e(route('subcategory.update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <input type="hidden" name="subcategory_id" value="<?php echo e($allsubcategories->id); ?>">
                       <select name="category_id" id="">
                        <option  value="">--Select Category--</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  value="<?php echo e($category->id); ?>" <?php echo e(($category->id == $allsubcategories->category_id)?'selected': ''); ?>><?php echo e($category->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>

                    </div>

                    <div class="form-group mt-3">
                        <label for="" class="form-label">Subcategory Name</label>
                        <input type="text" name="subcategory_name" class="form-control" value="<?php echo e($allsubcategories->subcategory_name); ?>">
                        <?php $__errorArgs = ['subcategory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($message); ?></strong>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(session('exists')): ?>
                    <div class="alert alert-success"><?php echo e(session('exists')); ?></div>
                    <?php endif; ?>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary ">Update Subcategory</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel-CTI-2106\fade\resources\views/admin/subcategory/edit.blade.php ENDPATH**/ ?>