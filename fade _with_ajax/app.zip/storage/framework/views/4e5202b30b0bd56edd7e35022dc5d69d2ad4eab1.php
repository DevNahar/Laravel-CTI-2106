
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('product.list')); ?>">Product List</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('add.color.size')); ?>">Product Color & size</a></li>
    </ol>
</div>
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header"><h3>Color List</h3></div>
            <div class="card-body">
                <table class="table table-striped">
                    <tr>
                        <th>SI</th>
                        <th>Color Name</th>
                        <th>Color</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $colorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($color->color_name); ?></td>
                        <td><button class="p-2 mr-2" style="background-color: <?php echo e($color->color_code); ?>; border:none;"></button><?php echo e($color->color_code); ?></td>                        
                                              
                        <td><a href="" class="btn btn-danger btn-xs sharp"><i class="fa fa-trash"></i></a></td>
                        </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card border border-primary">
            <div class="card-header bg-primary"><h3 class="text-white">Add Colors</h3></div>
            <div class="card-body">
                <form action="<?php echo e(route('add.color')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-label">Color Name</label>
                        <input type="text" class="form-control" name="color_name" >
                    </div>
                    <div class="form-group">
                        <label class="form-label">Color Code</label>
                        <input type="text" class="form-control" name="color_code">
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">Add Color</button>
                    </div>
                    
                </form>

            </div>
        </div>
    </div>
    <div class="col-lg-8 mt-5">
        <div class="card">
            <div class="card-header"><h3>Size List</h3></div>
            <div class="card-body">
                <table class="table table-striped">
                    <tr>
                        <th>SI</th>
                        <th>Size Name</th>                        
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $sizeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($size->color_size); ?></td>                                              
                                              
                        <td><a href="" class="btn btn-danger btn-xs sharp"><i class="fa fa-trash"></i></a></td>
                        </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4 mt-5">
        <div class="card border border-primary">
            <div class="card-header bg-primary"><h3 class="text-white">Add Size</h3></div>
            <div class="card-body">
                <form action="<?php echo e(route('add.size')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="form-label">Size Name</label>
                        <input type="text" class="form-control" name="color_size" >
                    </div>
                   
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">Add Size</button>
                    </div>
                    
                </form>

            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel-CTI-2106\fade\resources\views/admin/product/color_size.blade.php ENDPATH**/ ?>