<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('add.product')); ?>">Product</a></li>
    </ol>
</div>
<div class="row">
    <div class="col-lg-8 m-auto">
        <div class="card border border-primary">
            <div class="card-header bg-primary"><h3 class="text-white"> Add Product</h3></div>
            <div class="card-body">
                
                <form action="<?php echo e(route('product.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">

                                <select name="category_id" id="category_id" class="form-control">
                                    <option value="">--Select Category--</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">

                                <select name="subcategory_id" id="subcategory_id" class="form-control">
                                    <option value="">--Select Subcategory--</option>
                                    

                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-label">Product Name</label>
                                <input type="text" name="product_name"  class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-label">Product Price</label>
                                <input type="text" name="product_price"  class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-label">Product Discount</label>
                                <input type="text" name="discount"  class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-label">Product Brand</label>
                                <input type="text" name="brand"  class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label class="form-label">Short Description</label>
                                <input type="text" name="short_desp"  class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label class="form-label">Long Description</label>
                              <div><textarea name="long_desp" id="summernote" class="form-control" cols="85" rows="5"></textarea>
                              </div></div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-label">Preview Image</label>
                                <input type="file" name="preview"  class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-label">Thumbnails Image</label>
                                <input type="file" name="thumbnails[]" multiple  class="form-control">
                            </div>
                        </div>
                        <div class="col-lg-12 mt-4" >
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-primary ">Add Product</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script>
    $(document).ready(function() {
  $('#summernote').summernote();
});
    </script>
<script>
    $('#category_id').change(function(){
        let categoryValue = $(this).val();
        // alert(categoryValue);

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type:'POST',
            url: '/getsubcategory',
            data:{'c_id': categoryValue},
            success:function(data){
                $('#subcategory_id').html(data);
            }
        });


    });

</script>



<?php if(session('preview')): ?>
<script>
    Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Preview image Added!!',
  showConfirmButton: false,
  timer: 1500
})
</>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel-CTI-2106\fade\resources\views/admin/product/index.blade.php ENDPATH**/ ?>