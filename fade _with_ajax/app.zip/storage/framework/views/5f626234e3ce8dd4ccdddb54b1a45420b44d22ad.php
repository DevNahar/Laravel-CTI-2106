;
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="">Home</a></li>
        <li class="breadcrumb-item "><a href="">Categoty</a></li>
        <li class="breadcrumb-item active"><a href="">Edit Categoty</a></li>
    </ol>
</div>

<div class="row">
    <div class="col-lg-6 m-auto">
        <div class="card">
            <div class="card-header bg-primary "> <h3 class="text-white">Edit Categary</h3> </div>
            <div class="card-body">
                <?php if(session('category_update')): ?>
                        <div class="alert alert-success"><?php echo e(session('category_update')); ?></div>

                    <?php endif; ?>
                <form action="<?php echo e(route('category.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="hidden" value="<?php echo e($category_info->id); ?>" name="category_id">
                        <label class="form-label">Category Name</label>
                        <input type="text" name="category_name" value="<?php echo e($category_info->category_name); ?>"  class="form-control">
                        
                    </div>
                    <div class="form-group">
                        <label class="form-label">Category Image</label>
                        <input type="file" name="category_image"  class="form-control"  onchange="document.getElementById('img').src = window.URL.createObjectURL(this.files[0])">
                        <img src="<?php echo e(asset('uploads/categories')); ?>/<?php echo e($category_info->category_image); ?>" id="img" width="100" alt="">
                        
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary ">Update Category</button>
                    </div>

                    </div>
                </form>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel-CTI-2106\fade\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>