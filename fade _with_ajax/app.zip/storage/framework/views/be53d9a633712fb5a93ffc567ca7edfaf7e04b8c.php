<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('users')); ?>">Users</a></li>
    </ol>
</div>
<div class="container">
    <div class="row">
        <div class="col-lg-12 m-auto">
            <div class="card">
                <div class="card-header bg-primary"><h3 class="text-white">User List (<?php echo e($total_user); ?>)</h3></div>
                <?php if(session('delete')): ?>
                    <div class="alert alert-success"><?php echo e(session('delete')); ?></div>


                <?php endif; ?>


                <div class="card-body">
                    <table class="table table-striped">
                        <tr>
                            <th class="bg-dark text-white">Sr</th>
                            <th>User pic</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td class="bg-dark text-white w-5"><?php echo e(++$key); ?></td>
                            <td>
                                <?php if($user->profile_photo == null): ?>
                                        <img src="<?php echo e(Avatar::create($user->name)->toBase64()); ?>" width="50" />

                                    <?php else: ?>
                                         <img src="<?php echo e(asset('/uploads/users')); ?>/<?php echo e($user->profile_photo); ?>" width="50"
                                        alt="hhh" />
                                    <?php endif; ?>

                            </td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td> <a href="<?php echo e(route('del.user', $user->id)); ?>" class="btn btn-danger btn-xs sharp"><i class="fa fa-trash"></i></a></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel-CTI-2106\fade\resources\views/admin/users/user_list.blade.php ENDPATH**/ ?>