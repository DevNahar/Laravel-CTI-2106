<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('category')); ?>">Category</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('subcategory')); ?>">Subcategory</a></li>
    </ol>
</div>
<div class="row">
    <div class="col-lg-8">
        <div class="card border border-primary">
            <div class="card-header bg-primary"><h3 class="text-white">Subcategory List</h3></div>
            <div class="card-body">
                <?php if(session('subcategory_delete')): ?>
        <div class="alert alert-success"><?php echo e(session('subcategory_delete')); ?></div>

        <?php endif; ?>
            <?php if(session('subupdate')): ?>
            <div class="alert alert-success"><?php echo e(session('subupdate')); ?></div>

            <?php endif; ?>
                <table class="table table-striped">
                    <tr>
                        <th>Sl</th>
                        <th>Category Name</th>
                        <th>Subcategory Name</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $allsubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($subcategory->rel_to_category->category_name); ?></td>
                        <td><?php echo e($subcategory->subcategory_name); ?></td>
                        <td>
                            <a href="<?php echo e(route('subcategory.edit', $subcategory->id)); ?>" class="btn btn-info btn-xs sharp"><i class="fa fa-pencil"></i></a>
                            <a href="<?php echo e(route('subcategory.delete', $subcategory->id )); ?>" class="btn btn-danger btn-xs sharp"><i class="fa fa-trash"></i></a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card border border-primary">
            <div class="card-header bg-primary"><h3 class="text-white">Add Subcategory</h3></div>

            <div class="card-body">
                <?php if(session('subcategoryadd')): ?>
            <div class="alert alert-success"><?php echo e(session('subcategoryadd')); ?></div>
            <?php endif; ?>
                <form action="<?php echo e(route('subcategory.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                       <select name="category_id" id="">
                        <option  value="">--Select Category--</option>
                        <?php $__currentLoopData = $allcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>

                    </div>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($message); ?></strong>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-group mt-3">
                        <label for="" class="form-label">Subcategory Name</label>
                        <input type="text" name="subcategory_name" class="form-control">
                        <?php $__errorArgs = ['subcategory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($message); ?></strong>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(session('exists')): ?>
                    <div class="alert alert-success"><?php echo e(session('exists')); ?></div>
                    <?php endif; ?>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary ">Add Subcategory</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<div class="col-lg-8">
    <div class="card border border-primary">
        <div class="card-header bg-primary"><h3 class="text-white">Soft Delete Subcategory List</h3></div>
        <div class="card-body">

            <table class="table table-striped">
                <tr>
                    <th>Sl</th>
                    <th>Category Name</th>
                    <th>Subcategory Name</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $allsubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($subcategory->rel_to_category->category_name); ?></td>
                    <td><?php echo e($subcategory->subcategory_name); ?></td>
                    <td>
                        <a href="<?php echo e(route('subcategory.edit', $subcategory->id)); ?>" class="btn btn-info btn-xs sharp"><i class="fa fa-pencil"></i></a>
                        <a href="<?php echo e(route('subcategory.delete', $subcategory->id )); ?>" class="btn btn-danger btn-xs sharp"><i class="fa fa-trash"></i></a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel-CTI-2106\fade\resources\views/admin/subcategory/index.blade.php ENDPATH**/ ?>